document.addEventListener("DOMContentLoaded", function () {
    function showContent(engineType) {
        let content = document.getElementById('content');

        let engineInfo = {
            bike: {
                gif: "bike-engine.gif",
                description: `
                    <h2>Bike Engine</h2>
                    <p>Bikes usually have single-cylinder or twin-cylinder internal combustion engines.</p>
                    <ul>
                        <li>Lightweight and fuel-efficient</li>
                        <li>Uses air-cooling or liquid-cooling</li>
                        <li>Common fuel: Petrol</li>
                    </ul>
                `
            },
            car: {
                gif: "car-engine.gif",
                description: `
                    <h2>Car Engine</h2>
                    <p>Cars typically have inline, V-shaped, or boxer engines working on the four-stroke cycle.</p>
                    <ul>
                        <li>4 to 8 cylinders</li>
                        <li>Uses liquid cooling</li>
                        <li>Common fuel: Petrol or Diesel</li>
                    </ul>
                `
            },
            heavy: {
                gif: "truck-engine.gif",
                description: `
                    <h2>Heavy Vehicle Engine</h2>
                    <p>Trucks and buses use large diesel engines for better torque and fuel efficiency.</p>
                    <ul>
                        <li>More than 6 cylinders</li>
                        <li>Uses turbochargers</li>
                        <li>Common fuel: Diesel</li>
                    </ul>
                `
            },
            ship: {
                gif: "ship-engine.gif",
                description: `
                    <h2>Ship Engine</h2>
                    <p>Ships use large marine diesel engines or turbine-based engines.</p>
                    <ul>
                        <li>Massive multi-cylinder design</li>
                        <li>Highly efficient at low RPM</li>
                        <li>Common fuel: Heavy fuel oil (HFO)</li>
                    </ul>
                `
            }
        };

        let selectedEngine = engineInfo[engineType];
        if (selectedEngine) {
            content.innerHTML = `
                ${selectedEngine.description}
                <img src="${selectedEngine.gif}" alt="${engineType} Engine" class="engine-gif">
                <h3>Performance Calculation</h3>
                <label for="power">Enter Engine Power (HP):</label>
                <input type="number" id="power" placeholder="Enter HP">
                <label for="torque">Enter Torque (Nm):</label>
                <input type="number" id="torque" placeholder="Enter Torque">
                <button onclick="calculatePerformance('${engineType}')">Calculate Performance</button>
                <div id="performance-result"></div>
            `;
        }
    }

    window.showContent = showContent;

    window.calculatePerformance = function(engineType) {
        let power = document.getElementById('power').value;
        let torque = document.getElementById('torque').value;
        let resultDiv = document.getElementById('performance-result');

        if (!power || !torque) {
            resultDiv.innerHTML = "<p style='color: red;'>Please enter valid values for power and torque.</p>";
            return;
        }

        power = parseFloat(power);
        torque = parseFloat(torque);

        let speed = (power * 750) / torque;  // Approximate speed calculation
        let brakeThermalEfficiency = (power * 100) / (torque * 2);  // Hypothetical efficiency calculation

        let reliabilityReport;
        if (brakeThermalEfficiency > 35) {
            reliabilityReport = "Excellent Engine Performance!";
        } else if (brakeThermalEfficiency > 25) {
            reliabilityReport = "Good Performance with Some Efficiency Loss.";
        } else {
            reliabilityReport = "Needs Optimization, High Fuel Consumption!";
        }

        resultDiv.innerHTML = `
            <h4>Performance Report:</h4>
            <p>Approximate Speed: <b>${speed.toFixed(2)} RPM</b></p>
            <p>Brake Thermal Efficiency: <b>${brakeThermalEfficiency.toFixed(2)}%</b></p>
            <p><b>${reliabilityReport}</b></p>
        `;
    };
});
